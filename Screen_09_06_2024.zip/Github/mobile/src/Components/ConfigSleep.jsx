import { useEffect, useState } from 'react';
import sleepIcon from "../assets/sleep.svg";

export default function ConfigSleep({ sleepingPeople, test }) {
  const [inputtedSleepingPeople, setSleep] = useState(sleepingPeople || []);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    localStorage.setItem("name", "Anya");

    let adress = ""
    if (test) {
      adress = "ws://localhost:3000/"
    } else {
      adress = "ws://" + window.location.host + "/"
    }
    const socketInstance = new WebSocket(adress)
    setSocket(socketInstance);

    return () => {
      socketInstance.close()
    }
  }, [])

  useEffect(() => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ "type": "data", "component": "ConfigSleep", "sleepingPeople": inputtedSleepingPeople }));
    }
  }, [inputtedSleepingPeople]);

  function removeItemFromArray(array, itemToRemove) {
    return array.filter(item => item !== itemToRemove);
  }

  function handleClick() {
    const name = localStorage.getItem("name");
    if (inputtedSleepingPeople.includes(name)) {
      setSleep(removeItemFromArray(inputtedSleepingPeople, name));
    } else {
      setSleep([...inputtedSleepingPeople, name]);
    }
  }

  return (
    <div className="w-full bg-gray6 rounded-3xl p-4 flex flex-row items-center relative">
      <img src={sleepIcon} alt="" className="h-10 mr-3" />
      <h2 className="text-white text-2xl">Sleep</h2>
      <button
        onClick={handleClick}
        className={`absolute right-4 h-10 w-16 rounded-full flex flex-row items-center p-1 transition-all duration-300 ease-in-out ${inputtedSleepingPeople.includes(localStorage.getItem("name")) ? 'justify-end bg-[#AD4BD5]' : 'justify-start bg-gray4'}`}
      >
        <span className="h-8 w-8 rounded-full bg-white"></span>
      </button>
    </div>
  );
}
