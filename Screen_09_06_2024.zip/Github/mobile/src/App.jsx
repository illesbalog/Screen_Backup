import { useEffect, useState } from 'react'
import ConfigPublicTransport from './Components/ConfigPublicTransport'
import ConfigNotes from './Components/ConfigNotes'
import ConfigSleep from './Components/ConfigSleep'
import { VscAccount } from "react-icons/vsc"
import { BiSolidUserAccount } from "react-icons/bi"
import { MdSwitchAccount } from "react-icons/md"
import { IconContext } from "react-icons"



function App() {
  const test = false

  const configComponentsMap = {
    PublicTransport: ConfigPublicTransport,
    Notes: ConfigNotes,
    Sleep: ConfigSleep,
  }

  const [widgets, setWidgets] = useState([])

  const allWidgets = ["Notes", "Sleep", "PublicTransport"]
  const eventEmitter = new EventTarget();

  useEffect(() => {
    let adress = ""
    if (test) {
      adress = "ws://localhost:3000/"
    } else {
      adress = "ws://" + window.location.host + "/"
    }
    const socketInstance = new WebSocket(adress)

    socketInstance.addEventListener('open', (event) => {
      console.log('Connected to the WebSocket server');
      socketInstance.send(JSON.stringify({ "type": "init", "component": "Mobile" }))
    })
    socketInstance.addEventListener('message', (event) => {
      const response = JSON.parse(event.data)
      if (response.type == "data") {
        if ("widgets" in response) {
          setWidgets(response.widgets)
          socketInstance.close()
        }
      }
    })
    return () => {
      socketInstance.close()
    }
  }, [])

  return (
    <div className='p-5 font-poppins mx-auto max-w-md'>
      {/* <div className="flex justify-start w-full mx-auto">
        <h1 className='text-gray1 text-xl font-bold mb-2 ml-4'>
          Widgets
        </h1>
        <IconContext.Provider value={{ size:"2.2em", color: "#8E8E93" }}>
          <MdSwitchAccount className='absolute my-auto right-2'/>
        </IconContext.Provider> 
      </div> */}
      
      <div className='flex flex-col items-center gap-4'>
        {allWidgets.map((componentName, index) => {
          const widget = widgets.find(widget => widget.type === componentName)
          if (widget) {
            const Component = configComponentsMap[componentName];
            return <Component key={index} test={test} {...widget} />;
          } else {
            return null
          }
        })}
      </div>
      
      <div className="flex justify-center w-full mx-auto">
        <h1 className='text-white text-2xl mb-6'>
          
        </h1>
      </div>

    </div>
  )
}

export default App
