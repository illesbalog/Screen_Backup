/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        poppins: ["poppins"]
      },
      colors: {
        "gray1": "#8E8E93",
        "gray2": "#636366",
        "gray3": "#48484A",
        "gray4": "#3A3A3C",
        "gray5": "#2C2C2E",
        "gray6": "#1C1C1E",

      }
    },
  },
  plugins: [],
}