import { useState, useEffect } from "react";
import moon from '../../assets/moon.png';
import grayscale_moon from '../../assets/grayscale_moon.png';

export default function Sleep() {
	const [sleep, setSleep] = useState([]);

	useEffect(() => {
		const socket = new WebSocket("ws://" + window.location.host + "/")
		socket.addEventListener('open', (event) => {
			socket.send(JSON.stringify({ "type": "init", "component": "Sleep" }))
		});

		socket.addEventListener('message', (event) => {
			const response = JSON.parse(event.data);
			if (response.type == "data") {
				if ("sleepingPeople" in response) {
					setSleep(response.sleepingPeople);
				}
			}
			
		});

		return () => {
			socket.close()
		}
	}, []);

	function setMoon(sleepArray) {
		if (sleepArray.length == 0) {
			return {
				display: 'none',
			}
		} else {
			return {
				display: 'block',
			}
		}
	}
	function setGrayscaleMoon(sleepArray) {
		if (sleepArray.length == 0) {
			return {
				display: 'block',
			}
		} else {
			return {
				display: 'none',
			}
		}
	}
	function setText(sleep) {
		if (sleep.length == 0) {
		 return "No one is sleeping"
		}
		let text = "";
		sleep.forEach((element, index) => {
			if (sleep.length - 2 === index) {
				text += element + " and "
			} else if (sleep.length - 1 === index) {
				text += element + " "
			} else {
				text += element + ", "
			}
			
		})
		text += "are sleeping"
		return text
	}

	return (
		<div className='h-[275px] w-[930px] rounded-[32px] bg-[rgba(90,90,90,0.75)] backdrop-blur-[30px] shadow-2xl flex flex-row justify-between items-center pl-[40px] pr-[20px]'>
			<div className="text-white text-[65px]">
				{setText(sleep)}
			</div>
			<div className="w-[220px] h-[220px] flex-shrink-0">
				<img
					src={moon}
					alt="State Image"
					style={setMoon(sleep)}
					className="w-full h-full"
				/>
				<img
					src={grayscale_moon}
					alt="State Image"
					style={setGrayscaleMoon(sleep)}
					className="w-full h-full"
				/>
			</div>
			
		</div>
	);	
}
