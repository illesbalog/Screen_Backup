import { useState, useEffect, useRef } from 'react';

export default function DateComponent() {
  const daysOfTheWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const [date, setDate] = useState(getFormattedDate());
  const intervalRef = useRef(null);

  useEffect(() => {
    const now = new Date();
    const millisecondsUntilMidnight = 
      (24 - now.getHours()) * 3600 * 1000 - 
      now.getMinutes() * 60 * 1000 - 
      now.getSeconds() * 1000 - 
      now.getMilliseconds();

    const timeout = setTimeout(() => {
      handleSettingInterval();
    }, millisecondsUntilMidnight);

    return () => {
      clearTimeout(timeout);
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  function handleSettingInterval() {
    setDate(getFormattedDate());
    intervalRef.current = setInterval(() => {
      setDate(getFormattedDate());
    }, 86400000); // 24 hours in milliseconds
  }

  function getFormattedDate() {
    const now = new Date();
    const dayName = daysOfTheWeek[now.getDay()];
    const day = String(now.getDate()).padStart(2, '0'); // ensures it's always 2 digits
    const month = String(now.getMonth() + 1).padStart(2, '0'); // ensures it's always 2 digits
    return `${day}. ${month}${"\u00A0\u00A0\u00A0"}|${"\u00A0\u00A0\u00A0"}${dayName}`;
  }

  return (
    <div className='flex items-center h-full justify-center text-white text-[65px]'>
      {date}
    </div>
  );
}
