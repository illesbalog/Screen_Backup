import { useState, useEffect, useRef } from 'react';

export default function Time() {
  const [time, setTime] = useState(getFormattedTime());
  const intervalRef = useRef(null);

  useEffect(() => {
    const now = new Date();
    const millisecondsUntilNextMinute = (60 - now.getSeconds()) * 1000;

    const timeout = setTimeout(() => {
      handleSettingInterval();
    }, millisecondsUntilNextMinute);

    return () => {
      clearTimeout(timeout);
      if (intervalRef.current !== null) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  function handleSettingInterval() {
    setTime(getFormattedTime());
    intervalRef.current = setInterval(() => {
      setTime(getFormattedTime());
    }, 60000);
  }

  function getFormattedTime() {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    return `${hours} : ${minutes}`;
  }

  return (
    <div className='flex items-center h-full justify-center font-poppins text-white text-[270px]'>
      {time}
    </div>
  );
}
