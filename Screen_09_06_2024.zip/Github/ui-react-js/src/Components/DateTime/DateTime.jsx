import Time from './SubComponents/Time'
import Date from './SubComponents/Date'

export default function DateTime() {
	return (
		<div className='h-[570px] w-[930px]  mx-auto flex flex-col gap-[10px]'>
			<div className='h-[420px] w-[930px] rounded-t-[32px] rounded-b-[16px] bg-[rgba(90,90,90,0.75)] backdrop-blur-[30px] shadow-2xl'>
				<Time/>
			</div>
			<div className='h-[140px] w-[930px] rounded-t-[16px] rounded-b-[32px] shadow-2xl bg-[rgba(90,90,90,0.75)] backdrop-blur-[30px]'>
				<Date/>
			</div>
		</div>
	)
}

// linear-gradient(to top, rgba(90, 90, 90, 0.3) 0%, rgba(90, 90, 90, 0.9) 100%)