import { useEffect, useState } from "react";

export default function Notes() {
	const [content, setContent] = useState("")

	useEffect(() =>{
		const socket = new WebSocket('ws://localhost:3000');
		socket.addEventListener('open', (event) => {
		  socket.send(JSON.stringify({ "type": "init", "component": "Notes" }))
		});
		socket.addEventListener('message', (event) => {
			const response = JSON.parse(event.data)
		  if ("content" in response) {
				setContent(response.content)
			}
		})
		return () => {
			socket.close()
		}
	  
	}, [])
	return (
			<div className='h-[570px] w-[930px] rounded-[32px] bg-[rgba(90,90,90,0.75)] backdrop-blur-[30px] shadow-2xl text-[poppins]'>
				<div className="text-gray-200 pt-[10px] text-[65px] flex flex-row justify-center">
					Notes
				</div>
				<div className="text-white px-[60px] py-[20px] text-[40px] overflow-hidden">
					{content}
				</div>
			</div>
	)
}