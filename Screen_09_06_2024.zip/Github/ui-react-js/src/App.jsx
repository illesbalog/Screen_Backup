import DateTime from './Components/DateTime/DateTime'
import PublicTransport from './Components/PublicTransport/PublicTransport'
import Notes from './Components/Notes/Notes'
import Sleep from './Components/Sleep/Sleep'
import Setting from './Components/Settings/Settings'
import blue_purple_orange from './assets/blue_purple_orange.jpg';
import { useEffect, useState } from 'react';

export default function App() {
  const componentsMap = {
    DateTime: DateTime,
    PublicTransport: PublicTransport,
    Notes: Notes,
    Sleep: Sleep,
  };

  const [firstColumnComponents, setFirstColumnComponents] = useState([])
  const [secondColumnComponents, setSecondColumnComponents] = useState([])
  const [settingsState, setSettingsState] = useState(false)

  useEffect(() =>{
    const socket = new WebSocket("ws://" + window.location.host + "/")
    socket.addEventListener('open', (event) => {
      console.log('Connected to the WebSocket server');
      socket.send(JSON.stringify({ "type": "init", "component": "App" }))
    });
    socket.addEventListener('message', (event) => {
      const response = JSON.parse(event.data)
      if (response.type == "data") {
        if ("widgets" in response) {
          const widgets = response.widgets.map(widget => {
            const { type, height } = widget;
            return { type, height };
          });
          let secondColumnWidgets = JSON.parse(JSON.stringify(widgets))
          let totalHeight = 0;
          const firstColumnWidgets = [];
  
          for (const widget of widgets) {
            if (totalHeight + widget.height > 8) {
              break;
            }
            totalHeight += widget.height;
            firstColumnWidgets.push(widget);
          }
          setFirstColumnComponents(firstColumnWidgets)
          setSecondColumnComponents(secondColumnWidgets.slice(firstColumnWidgets.length))
  
        }
      }
      if ("settings" in response) {
        setSettingsState(response.settings)
      }
    })
    return () => {
			socket.close()
		}

  }, [])

  return (
      <div style={{ backgroundImage: `url(${blue_purple_orange})` }} className="h-[1200px] w-[1920px] p-5 flex flex-row gap-5 justify-center font-poppins">
        <div className="flex flex-col gap-5 items-center">
          {firstColumnComponents.map((componentName, index) => {
            // Get the component from the map
            const Component = componentsMap[componentName["type"]];

            // Render the component
            return <Component key={index} />;
          })}
        </div>
        <div className="flex flex-col gap-5 items-center">
          {secondColumnComponents.map((componentName, index) => {
            // Get the component from the map
            const Component = componentsMap[componentName["type"]];

            // Render the component
            return <Component key={index} />;
          })}
        </div>
        <div className={`${settingsState ? '' : 'hidden'}`}>
          <Setting />
        </div>
      </div>
  )
}