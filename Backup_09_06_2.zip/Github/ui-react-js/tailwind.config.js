/** @type {import('tailwindcss').Config} */
import blue_purple_orange from './src/assets/blue_purple_orange';


export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      backgroundImage: {
        'blue-purple-orange': "url('./src/assets/blue_purple_orange')",
      },
      fontFamily: {
        poppins: ["poppins"],
      },
      backgroundImage: {
        'custom-gradient': 'linear-gradient(to top, rgba(90, 90, 90, 0.7) 0%, rgba(90, 90, 90, 1) 100%)',
      },
      colors: {
        "gray1": "#8E8E93",
        "gray2": "#636366",
        "gray3": "#48484A",
        "gray4": "#3A3A3C",
        "gray5": "#2C2C2E",
        "gray6": "#1C1C1E",
      },
    },
  },
  plugins: [],
}