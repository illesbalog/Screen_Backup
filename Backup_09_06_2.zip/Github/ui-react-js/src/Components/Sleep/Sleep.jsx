import { useState, useEffect } from "react"
import sleepIcon from '../../assets/sleep.svg'
import grayscale_moon from '../../assets/grayscale_moon.png'

export default function Sleep({ test }) {
	const [sleepState, setSleepState] = useState(false);
	const [timeElapsed, setTimeElapsed] = useState(0);
	let timer;

	useEffect(() => {
		let address = ""
		if (test) {
			address = "ws://localhost:3000/"
		} else {
			address = "ws://" + window.location.host + "/"
		}
		const socket = new WebSocket(address)
		socket.addEventListener('open', (event) => {
			socket.send(JSON.stringify({ "platform": "screen", "type": "init", "component": "Sleep" }))
		});

		socket.addEventListener('message', (event) => {
			const response = JSON.parse(event.data);
			if (response.type == "data") {
				if ("state" in response) {
					setSleepState(response.state);
				}
			}
		});

		return () => {
			socket.close()
		}
	}, [test]);

	useEffect(() => {
		if (sleepState) {
			timer = setInterval(() => {
				setTimeElapsed(prevTime => prevTime + 1);
			}, 1000);
		} else {
			clearInterval(timer);
			setTimeElapsed(0);
		}

		return () => clearInterval(timer);
	}, [sleepState]);

	function setColoredSleepIcon(sleepState) {
		if (sleepState) {
			return {
				display: 'block',
			}
		} else {
			return {
				display: 'none',
			}
		}
	}

	function setGrayscaleSleepIcon(sleepState) {
		if (sleepState) {
			return {
				display: 'none',
			}
		} else {
			return {
				display: 'block',
			}
		}
	}

	function displaySleepState(sleepState) {
		if (sleepState) {
			const hours = String(Math.floor(timeElapsed / 3600)).padStart(2, '0')
			const minutes = String(Math.floor((timeElapsed % 3600) / 60)).padStart(2, '0')
			
			return (
				<>
					<div className="text-white text-[100px]">{hours}:{minutes}</div>
					<div className='w-11/12 h-[5px] rounded-xl bg-gray4 mx-auto'></div>
					<p className="text-gray1 text-5xl my-4 leading-normal">Time since falling asleep</p>
				</>
			)
		} else {
			return (
				<>
					<div className="flex justify-center items-center text-gray1 text-5xl">
						Nothing to Display
					</div>
				</>
			)
		}
	}

	return (
		<div className='h-[275px] w-[930px] flex flex-row gap-[10px]'>
			<div className="rounded-l-[32px] rounded-r-[16px] bg-gray6 w-[645px] h-[275px] flex flex-col items-center justify-center">
				{displaySleepState(sleepState)}
			</div>
			<div className="rounded-l-[16px] rounded-r-[32px] bg-gray6 w-[275px] h-[275px]  flex justify-center item-center p-10">
				<img src={sleepIcon} alt="" className={`${sleepState ? 'grayscale-0' : 'grayscale'}`}/>
			</div>
		</div>
	)
}
