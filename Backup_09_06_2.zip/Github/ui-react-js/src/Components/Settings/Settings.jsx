import { useEffect, useState } from "react"


export default function Settings({ test }) {
	const [ipv4, setIpv4] = useState("")

	useEffect(() => {
		let adress = ""
    if (test) {
      adress = "ws://localhost:3000/"
    } else {
      adress = "ws://" + window.location.host + "/"
    }
    const socket = new WebSocket(adress)
		socket.addEventListener('open', (event) => {
			socket.send(JSON.stringify({ "platform": "screen", "type": "init", "component": "Settings" }))
		});

		socket.addEventListener('message', (event) => {
			const response = JSON.parse(event.data);
			if (response.type == "data") {
				if ("ipAddress" in response) {
					setIpv4(response.ipAddress)
					socket.close();
				}
			}
			
		})

		return () => {
			socket.close();
		}
	}, [])

	return (
		<div className="absolute left-0 top-0 w-[1920px] h-[1200px] backdrop-blur-[30px] flex justify-center items-center">
			<div className="rounded-[32px] bg-[rgba(90,90,90,0.75)] backdrop-blur-[30px] shadow-2xl flex flex-row justify-between items-center p-[50px] text-white text-[65px]">
				{ipv4}
			</div>
		</div>
	)
}