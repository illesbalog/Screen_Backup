import { useState, useEffect, useRef } from 'react'
import blue_purple_orange from "../../../assets/blue_purple_orange.jpg"

export default function Time() {
  const [time, setTime] = useState(getFormattedTime());
  const intervalRef = useRef(null);

  useEffect(() => {
    const now = new Date();
    const millisecondsUntilNextMinute = (60 - now.getSeconds()) * 1000;

    const timeout = setTimeout(() => {
      handleSettingInterval();
    }, millisecondsUntilNextMinute);

    return () => {
      clearTimeout(timeout);
      if (intervalRef.current !== null) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  function handleSettingInterval() {
    setTime(getFormattedTime());
    intervalRef.current = setInterval(() => {
      setTime(getFormattedTime());
    }, 60000);
  }

  function getFormattedTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${hours} : ${minutes}`;
  }
  

  return (
      <div style={{ backgroundImage: `url(${blue_purple_orange})` }} 
      className='flex items-center h-full rounded-t-[32px] rounded-b-[16px] justify-center font-poppins text-transparent text-[270px] font-bold bg-clip-text bg-contain'>
        {time}
      </div> 
  )
}
