import { useEffect, useState } from "react";

export default function Notes({ test }) {
	const [content, setContent] = useState("")

	useEffect(() =>{
		let adress = ""
    if (test) {
      adress = "ws://localhost:3000/"
    } else {
      adress = "ws://" + window.location.host + "/"
    }
    const socket = new WebSocket(adress)
		socket.addEventListener('open', (event) => {
		  socket.send(JSON.stringify({ "platform": "screen", "type": "init", "component": "Notes" }))
		});
		socket.addEventListener('message', (event) => {
			const response = JSON.parse(event.data)
			if (response.type == "data") {
				if ("content" in response) {
					setContent(response.content)
				}
			}
		  
		})
		return () => {
			socket.close()
		}
	  
	}, [])
	return (
			<div className='h-[570px] w-[930px] rounded-[32px] bg-gray6 text-[poppins] flex flex-col '>
				<div className="text-gray-200 my-auto text-[65px] text-center">
					Notes
				</div>
				<div className='w-11/12 h-[5px] rounded-xl bg-gray4 mx-auto'></div>
				<textarea spellCheck={false} rows={7} value={content} className="text-white px-[60px] py-[22px] mb-0 text-[40px] overflow-hidden block bg-transparent resize-none outline-none">
				</textarea>
			</div>
	)
}