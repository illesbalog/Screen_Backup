import { useState, useEffect } from 'react'

export default function PublicTransport({ test }) {
	const [origin, setOrigin] = useState("")
	const [destination, setDestination] = useState("")
	const [departure, setDeparture] = useState("")
	const [arrival, setArrival] = useState("")

	useEffect(() =>{
		let adress = ""
    if (test) {
      adress = "ws://localhost:3000/"
    } else {
      adress = "ws://" + window.location.host + "/"
    }
    const socket = new WebSocket(adress)
		socket.addEventListener('open', (event) => {
		  socket.send(JSON.stringify({ "platform": "screen", "type": "init", "component": "PublicTransport" }))
		});
		socket.addEventListener('message', (event) => {
			const response = JSON.parse(event.data)
			if (response.type == "data") {
				if ("origin" in response) {
					setOrigin(response.origin)
				}
				if ("destination" in response) {
					setDestination(response.destination)
				}
				if ("departure" in response) {
					const formattedDeparture = new Date(response.departure)
					setDeparture(`${formattedDeparture.getHours()}:${formattedDeparture.getMinutes()}`)
				}
				if ("arrival" in response) {
					const formattedArrival = new Date(response.arrival)
					console.log(formattedArrival)
					setArrival(`${formattedArrival.getHours()}:${formattedArrival.getMinutes()}`)
				}
			}
		  
		})
		return () => {
			socket.close()
		}
	  
	}, [])


	return (
		<div className='h-[275px] w-[930px] rounded-[32px] bg-gray6 flex flex-row justify-evenly items-center p-[16px]'>
			<div className='flex flex-col justify-evenly items-end text-[65px] text-[#fff]'>
				<div className=''>
					{origin}
				</div>
				<div className=''>
					{destination}
				</div>
			</div>
			<svg width="100px" height="100px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M12 4V20M12 20L8 16M12 20L16 16" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
			</svg>
			<div className='flex flex-col justify-evenly items-start text-[65px] text-white'>
				<div className=''>
					{departure}
				</div>
				<div className=''>
					{arrival}
				</div>
			</div>
		</div>
		
	)
}


