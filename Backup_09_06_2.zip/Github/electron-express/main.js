//os
import os from 'os'
import { EventEmitter } from 'events'
import { promises as fs } from 'fs'

//electron
import { app, BrowserWindow} from 'electron'

//express
import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
//websocket
import { WebSocketServer } from 'ws'

// hafas-client
import { createClient } from 'hafas-client'
import { profile as dbProfile } from 'hafas-client/p/db/index.js'


async function getLocalData() {
  const filePath = './data.json'
  try {
    const data = await fs.readFile(filePath, 'utf8')
    return JSON.parse(data)
  } catch (err) {
    console.error('Error:', err)
    throw err
  }
}

async function saveLocalData(newData) {
  const filePath = './data.json'
  try {
    // Get the current local data
    const currentData = await getLocalData()

    // Merge current data with new data, replacing matching items
    const updatedData = { ...currentData, ...newData }

    // Save the updated data back to data.json
    await fs.writeFile(filePath, JSON.stringify(updatedData, null, 2), 'utf8')
  } catch (err) {
    console.error('Error:', err)
    throw err
  }
}


async function startApp() {
	const test = false

	// get local data
	const localData = await getLocalData()
	let widgets = localData.widgets

	// init express
	const app = express()
  const __filename = fileURLToPath(import.meta.url)
  const __dirname = path.dirname(__filename)

  // Serve static files from the 'public' directory at the '/screen' route
	app.use('/mobile', express.static(__dirname + '/mobile'))
	app.use('', express.static(__dirname + '/mobile'))
	app.use('/screen', express.static(__dirname + '/screen'))
	app.use('', express.static(__dirname + '/screen'))

  const server = app.listen(3000, '0.0.0.0', () => {
		console.log('Server is running at http://localhost:3000')
	})


	// init hafas-client
	const userAgent = 'illesbalog@gmail.com'
	const client = createClient(dbProfile, userAgent)
	// init helper objects
	const eventEmitter = new EventEmitter()
	const wss = new WebSocketServer({ server })
	let connections = {
		"screen": {
			"App": new Set(),
			"Notes": new Set(),
			"PublicTransport": new Set(),
			"Sleep": new Set(),
		},
		"mobile": {
			"App": new Set(),
			"ConfigNotes": new Set(),
			"ConfigPublicTransport": new Set(),
			"ConfigSleep": new Set(),
		}
	}

	wss.on('connection', (ws) => {
		ws.on('message', (response) => {
			const packet = JSON.parse(response)
			if (packet.platform == "screen") {
				if (packet.type == "init") {
					if (packet.component == "App") {
						connections.screen.App.add(ws)
						ws.send(JSON.stringify({ "type": "data", "widgets": widgets }))
						ws.on("close", () => {
							connections.screen.App.delete(ws)
						})
					} else
					if (packet.component == "Notes") {
						connections.screen.Notes.add(ws)
						ws.send(JSON.stringify({ "type": "data", "content": (widgets.find(widget => widget.type === "Notes")).content }))
						ws.on("close", () => {
							connections.screen.App.delete(ws)
						})
					} else
					if (packet.component == "PublicTransport") {
						connections.screen.PublicTransport.add(ws)
						const publicTransport = widgets.find(widget => widget.type === "PublicTransport")
						ws.send(JSON.stringify({ "type": "data", "origin": publicTransport.origin, "destination": publicTransport.destination }))
						try {
								client.journeys(publicTransport.originEva, publicTransport.destinationEva, { results: 1 }).then((response) => {
									if (response.journeys[0].legs) {
										const journey = response.journeys[0]
										const legs = journey.legs
										const departure = legs[0].departure
										console.log(legs[legs.length - 1])
										const arrival = legs[legs.length - 1].arrival
		
										ws.send(JSON.stringify({ "type": "data", "departure": departure, "arrival": arrival }));
										if (journey.refreshToken && !test) {
											const refreshToken = journey.refreshToken
											const intervalId = setInterval(() => {
												client.refreshJourney(refreshToken).then(response => {
													const journey = response.journey
													if (journey.legs[0].departure && journey.legs[0].departure != departure && journey.legs[journey.legs.length - 1].arrival) {
														console.log(journey.legs[0].departure)
														ws.send(JSON.stringify({ "type": "data", "departure": journey.departure, "arrival": journey.legs[journey.legs.length - 1].arrival }))
													}
												})
											}, 3*60000)
											ws.on('close', () => {
												clearInterval(intervalId);
											})
		
										}
										
									}
								})
						} catch (error) {
								console.error("Firebase Functions fail at: getLocations", error);
								ws.send(JSON.stringify({ "type": "data", "error": true }));
						}
						ws.on("close", () => {
							connections.screen.App.delete(ws)
						})
					} else
					if (packet.component == "Sleep") {
						connections.screen.Sleep.add(ws)
						ws.send(JSON.stringify({ "type": "data", "state": (widgets.find(widget => widget.type === "Sleep")).state }))
						ws.on("close", () => {
							connections.screen.App.delete(ws)
						})
					} else
					if (packet.component == "Settings") {
						function getIPAddress() {
							const interfaces = os.networkInterfaces();
							for (const name of Object.keys(interfaces)) {
									for (const iface of interfaces[name]) {
											// Skip over non-ipv4 and internal (i.e., 127.0.0.1) addresses
											if (iface.family === "IPv4" && !iface.internal) {
													return iface.address;
											}
									}
							}
							return "Couldn't get Ip Adress";
						}
						const ipAddress = getIPAddress()
						ws.send(JSON.stringify({ "type": "data", "ipAddress": ipAddress }))
					}
				}
			} else
			if (packet.platform == "mobile") {
				if (packet.type == "init") {
					if (packet.component == "App") {
						ws.send(JSON.stringify({ "type": "data", "widgets": widgets }))

					}
				} else
				if (packet.type == "data") {
					if (packet.component == "App") {
						widgets = packet.widgets
						saveLocalData({"widgets": widgets})
						for (const connection of connections.screen.App) {
							connection.send(JSON.stringify({ "type": "data", "widgets": widgets }))
						}
					} else
					if (packet.component == "ConfigNotes") {
						const index = widgets.findIndex(widget => widget.type === 'Notes')
						if (index != -1) {
							const content = packet.content
							widgets[index].content = content
							saveLocalData({"widgets": widgets})
							for (const connection of connections.screen.Notes) {
								connection.send(JSON.stringify({ "type": "data", "content": content }))
							}
						}
					} else
					if (packet.component == "ConfigSleep") {
						const index = widgets.findIndex(widget => widget.type === 'Sleep')
						if (index != -1) {
							const state = packet.state
							widgets[index].state = state
							saveLocalData({"widgets": widgets})
							for (const connection of connections.screen.Sleep) {
								connection.send(JSON.stringify({ "type": "data", "state": state }))
							}
						}
					} else
					if (packet.component == "ConfigPublicTransport") {
						const index = widgets.findIndex(widget => widget.type === 'PublicTransport')
						if (index != -1) {
							widgets[index].origin = packet.origin
							widgets[index].destination = packet.destination;
							saveLocalData({"widgets": widgets})
							
							for (const connection of connections.screen.PublicTransport) {
								connection.send(JSON.stringify({ "type": "instruction", "command": "remountPublicTransport" }))
							}
						}
					}
				}
			}
			
		})
	})


	if (!test) {
		const mainWindow = new BrowserWindow({
			title: 'ui',
			autoHideMenuBar: true,
			fullscreen: true,
			webPreferences: {
				nodeIntegration: true,
				contextIsolation: false,
			}
		})
	
		mainWindow.on('ready-to-show', () => {
			mainWindow.show()
		})
		mainWindow.loadURL('http://localhost:3000/screen')
	}
}

app.whenReady().then(() => {
  startApp()
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})










// {
//   "widgets" : [
//     {"DateTime": {"type": "DateTime", "config": false, "height": 4}},
//     {"Notes": {"type": "Notes", "config": true, "height": 4, "content": "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit impedit perferendis soluta, sed ut dolorem, consequatur quo et voluptate, molestias unde! Similique, sed quidem ullam rem rerum officiis nemo eius."}},
//     {"PublicTransport": {"type": "PublicTransport", "config": true, "height": 2, "origin": "Beimerstetten", "originEva": "8000858", "destination": "Ulm Hbf", "destinationEva": "8000170"}},
//     {"Sleep": {"type": "Sleep", "config": true, "height": 2, "sleepingPeople": ["Anya", "Mirko"]}}
//   ]
// }









