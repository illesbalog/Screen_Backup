import { useEffect, useState } from 'react';
import publicTransportIcon from "../assets/publicTransport.svg";
import { IoIosArrowDown } from "react-icons/io";
import { IconContext } from "react-icons";

export default function ConfigPublicTransport({origin, destination, test}) {
  const [isToggleDivVisible, setIsToggleDivVisible] = useState(false);
  const [inputtedOrigin, setOrigin] = useState(origin);
  const [inputtedDestination, setDestination] = useState(destination);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    let adress = ""
    if (test) {
      adress = "ws://localhost:3000/"
    } else {
      adress = "ws://" + window.location.host + "/"
    }
    const socketInstance = new WebSocket(adress)
    setSocket(socketInstance);

    return () => {
      socketInstance.close();
    };
  }, []);

  useEffect(() => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ "platform": "mobile", type: "data", "component": "ConfigPublicTransport", "origin": inputtedOrigin, "destination": inputtedDestination }));
    }
  }, [inputtedOrigin, inputtedDestination]);

  function handleToggle() {
    setIsToggleDivVisible(prevState => !prevState);
  }

  function handleOriginChange(event) {
    setOrigin(event.target.value);
  }

  function handleDestinationChange(event) {
    setDestination(event.target.value)
  }

  return (
    <div className="w-full bg-gray6 rounded-3xl p-4 flex flex-col">
      <div onClick={handleToggle} className="flex flex-row items-center relative select-none cursor-pointer">
        <img src={publicTransportIcon} alt="" className="h-10 mr-3"/>
        <h2 className="text-white text-2xl">Public Transport</h2>
        <IconContext.Provider value={{ size:"1.5em", color:"#8E8E93" }}>
          <IoIosArrowDown className={`ml-auto mr-2 transition-all duration-300 ease-in-out ${isToggleDivVisible ? 'rotate-180' : ''}`}/>
        </IconContext.Provider>
      </div>
      <div className={`flex flex-col gap-3 transition-all duration-300 ease-in-out ${isToggleDivVisible ? 'max-h-[200px] opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
        <div className='w-full h-[1px] rounded-xl bg-gray4 mt-3'></div>
        <input type="text" spellCheck={false} placeholder='Origin' value={inputtedOrigin} onChange={handleOriginChange} className='w-full bg-gray4 rounded-xl text-xl p-3 text-white outline-none'/>
        <input type="text" spellCheck={false} placeholder='Destination' value={inputtedDestination} onChange={handleDestinationChange} className='w-full bg-gray4 rounded-xl text-xl p-3 text-white outline-none'/>
      </div>
    </div>
  );
}
