import { useEffect, useState } from 'react';
import notesSVG from "../assets/sticky-notes.svg";
import { IconContext } from "react-icons";
import { MdDelete } from "react-icons/md";

export default function ConfigNotes({ content, test }) {
  const [inputtedContent, setContent] = useState(content);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    const textarea = document.getElementById('notesTextarea')
    const adjustTextareaHeight = () => {
      textarea.style.height = 'auto';
      textarea.style.height = textarea.scrollHeight + 'px';
    }
    adjustTextareaHeight(); // Adjust height for default content
    textarea.addEventListener('input', adjustTextareaHeight)

    // Setup WebSocket
    let adress = ""
    if (test) {
      adress = "ws://localhost:3000/"
    } else {
      adress = "ws://" + window.location.host + "/"
    }
    const socketInstance = new WebSocket(adress)
    setSocket(socketInstance)

    return () => {
      textarea.removeEventListener('input', adjustTextareaHeight);
      socketInstance.close();
    };
  }, []);

  useEffect(() => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ "platform": "mobile", "type": "data", "component": "ConfigNotes", "content": inputtedContent }))
    }
  }, [inputtedContent]);

  function handleDelete() {
    setContent("");
    const textarea = document.getElementById('notesTextarea');
    textarea.style.height = 'auto'; // Reset height after deleting content
  }

  function handleChange(event) {
    setContent(event.target.value);
  }

  return (
    <div className="w-full bg-gray6 rounded-3xl p-4 flex flex-col gap-3">
      <div className="flex flex-row items-center">
        <img src={notesSVG} alt="" className="h-10 mr-3" />
        <h2 className="text-white text-2xl">Notes</h2>
        <IconContext.Provider value={{ size: "2em", color: "#8E8E93" }}>
          <MdDelete onClick={handleDelete} className='ml-auto mr-2 cursor-pointer' />
        </IconContext.Provider>
      </div>
      <div className='w-full h-[1px] rounded-xl bg-gray4'></div>
      <textarea
        id="notesTextarea"
        placeholder=". . ."
        value={inputtedContent}
        onChange={handleChange}
        rows={1}
        spellCheck={false}
        className="block w-full resize-none bg-transparent p-2 text-white text-xl outline-none hidden-scrollbar"
      />
    </div>
  )
}
